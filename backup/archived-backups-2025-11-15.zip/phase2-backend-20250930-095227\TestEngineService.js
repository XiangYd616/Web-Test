/**
 * 测试引擎服务
 * 统一管理所有测试引擎的调用和结果处理
 */

const { v4: uuidv4 } = require('uuid');

// 导入统一的测试类型定义
const { TestType, TestStatus } = require('../../../shared/types/unified-test-types');

// 导入所有测试引擎 - 完整列表
const performanceEngine = require('../../engines/performance/performanceTestEngine');
const seoEngine = require('../../engines/seo/seoTestEngine');
const securityEngine = require('../../engines/security/SecurityTestEngine');
const compatibilityEngine = require('../../engines/compatibility/CompatibilityTestEngine');
const apiEngine = require('../../engines/api/ApiTestEngine');
const stressEngine = require('../../engines/stress/StressTestEngine');
const uxEngine = require('../../engines/ux/uxTestEngine');
const infrastructureEngine = require('../../engines/infrastructure/infrastructureTestEngine');

// 导入扩展测试引擎
const accessibilityEngine = require('../../engines/accessibility/AccessibilityTestEngine');
const databaseEngine = require('../../engines/database/DatabaseTestEngine');
const networkEngine = require('../../engines/network/NetworkTestEngine');
const websiteEngine = require('../../engines/website/websiteTestEngine');
const contentEngine = require('../../engines/content/ContentTestEngine');
const documentationEngine = require('../../engines/documentation/DocumentationTestEngine');
const regressionEngine = require('../../engines/regression/RegressionTestEngine');
const automationEngine = require('../../engines/automation/AutomationTestEngine');
const clientsEngine = require('../../engines/clients/ClientsTestEngine');

/**

 * TestEngineService类 - 负责处理相关功能

 */
const servicesEngine = require('../../engines/services/ServicesTestEngine');

class TestEngineService {
  constructor() {
    // 使用统一的TestType常量映射所有引擎
    this.engines = {
      [TestType.PERFORMANCE]: performanceEngine,
      [TestType.SEO]: seoEngine,
      [TestType.SECURITY]: securityEngine,
      [TestType.COMPATIBILITY]: compatibilityEngine,
      [TestType.API]: apiEngine,
      [TestType.STRESS]: stressEngine,
      [TestType.UX]: uxEngine,
      [TestType.INFRASTRUCTURE]: infrastructureEngine,
      // 新增的测试引擎
      [TestType.ACCESSIBILITY]: accessibilityEngine,
      [TestType.DATABASE]: databaseEngine,
      [TestType.NETWORK]: networkEngine,
      [TestType.WEBSITE]: websiteEngine,
      [TestType.CONTENT]: contentEngine,
      [TestType.DOCUMENTATION]: documentationEngine,
      [TestType.REGRESSION]: regressionEngine,
      [TestType.AUTOMATION]: automationEngine,
      [TestType.CLIENTS]: clientsEngine,
      [TestType.SERVICES]: servicesEngine
    };

    this.activeTests = new Map();
    this.testResults = new Map();
  }

  /**
   * 获取所有可用的测试引擎
   */
  getAvailableEngines() {
    return Object.keys(this.engines);
  }

  /**
   * 检查测试引擎是否可用
   */
  async checkEngineAvailability(engineType) {
    const engine = this.engines[engineType];
    if (!engine) {
      return { available: false, error: '未知的测试引擎类型' };
    }

    try {
      if (typeof engine.checkAvailability === 'function') {
        return await engine.checkAvailability();
      }
      return { available: true };
    } catch (error) {
      return { available: false, error: error.message };
    }
  }

  /**
   * 启动测试
   */
  async startTest(testType, url, options = {}) {
    const engine = this.engines[testType];
    if (!engine) {
      throw new Error(`不支持的测试类型: ${testType}`);
    }

    // 检查缓存
    if (options.useCache !== false) {
      const cachedResult = this.getCachedResult(testType, url, options);
      if (cachedResult) {
        return {
          testId: cachedResult.id,
          status: 'completed',
          result: cachedResult.result,
          fromCache: true
        };
      }
    }

    const testId = uuidv4();
    const startTime = new Date();

    // 记录测试状态
    this.activeTests.set(testId, {
      id: testId,
      type: testType,
      url,
      status: 'running',
      progress: 0,
      startTime,
      message: '测试初始化中...'
    });

    try {
      // 根据不同引擎调用相应的方法
      let result;

      // 统一的配置对象
      const testConfig = { url, ...options };

      // 统一的测试执行方法映射
      const testMethodMap = {
        [TestType.PERFORMANCE]: 'runPerformanceTest',
        [TestType.SEO]: 'runSeoTest',
        [TestType.SECURITY]: 'runSecurityTest',
        [TestType.COMPATIBILITY]: 'runCompatibilityTest',
        [TestType.API]: 'runApiTest',
        [TestType.STRESS]: 'runStressTest',
        [TestType.UX]: 'runUxTest',
        [TestType.INFRASTRUCTURE]: 'runInfrastructureTest',
        [TestType.ACCESSIBILITY]: 'runAccessibilityTest',
        [TestType.DATABASE]: 'runDatabaseTest',
        [TestType.NETWORK]: 'runNetworkTest',
        [TestType.WEBSITE]: 'runWebsiteTest',
        [TestType.CONTENT]: 'runContentTest',
        [TestType.DOCUMENTATION]: 'runDocumentationTest',
        [TestType.REGRESSION]: 'runRegressionTest',
        [TestType.AUTOMATION]: 'runAutomationTest',
        [TestType.CLIENTS]: 'runClientsTest',
        [TestType.SERVICES]: 'runServicesTest'
      };

      const testMethod = testMethodMap[testType];
      if (!testMethod) {
        throw new Error(`不支持的测试类型: ${testType}`);
      }

      // 尝试调用特定的测试方法，如果不存在则使用通用方法
      if (typeof engine[testMethod] === 'function') {
        result = await engine[testMethod](testConfig);
      } else if (typeof engine.runTest === 'function') {
        // 使用通用的runTest方法
        result = await engine.runTest(testConfig);
      } else if (typeof engine.execute === 'function') {
        // 使用execute方法
        result = await engine.execute(testConfig);
      } else {
        throw new Error(`测试引擎 ${testType} 没有可用的执行方法`);
      }

      // 保存测试结果
      const finalResult = {
        id: testId,
        type: testType,
        url,
        result,
        startTime,
        endTime: new Date(),
        duration: Date.now() - startTime.getTime(),
        status: 'completed'
      };

      this.testResults.set(testId, finalResult);

      // 缓存结果（如果启用了缓存）
      if (options.useCache !== false) {
        this.setCachedResult(testType, url, options, finalResult);
      }

      // 更新测试状态
      this.activeTests.set(testId, {
        ...this.activeTests.get(testId),
        status: 'completed',
        progress: 100,
        endTime: new Date(),
        message: '测试完成'
      });

      return { testId, status: 'completed', result };

    } catch (error) {
      // 更新失败状态
      this.activeTests.set(testId, {
        ...this.activeTests.get(testId),
        status: 'failed',
        error: error.message,
        endTime: new Date(),
        message: '测试失败'
      });

      throw error;
    }
  }

  /**
   * 获取测试状态
   */
  getTestStatus(testId) {
    return this.activeTests.get(testId);
  }

  /**
   * 获取测试结果
   */
  getTestResult(testId) {
    return this.testResults.get(testId);
  }

  /**
   * 停止测试
   */
  async stopTest(testId) {
    const test = this.activeTests.get(testId);
    if (!test) {
      throw new Error('测试不存在');
    }

    if (test.status !== 'running') {
      throw new Error('测试已经结束');
    }

    // 尝试停止引擎中的测试
    const engine = this.engines[test.type];
    if (engine && typeof engine.stopTest === 'function') {
      try {
        await engine.stopTest(testId);
      } catch (error) {
        console.warn('停止引擎测试失败:', error);
      }
    }

    // 更新状态
    this.activeTests.set(testId, {
      ...test,
      status: 'cancelled',
      endTime: new Date(),
      message: '测试已取消'
    });

    return { success: true, message: '测试已停止' };
  }

  /**
   * 运行综合测试
   */
  async runComprehensiveTest(url, options = {}) {
    const testTypes = options.testTypes || ['performance', 'seo', 'security'];
    const results = {};
    const errors = {};

    for (const testType of testTypes) {
      try {
        const result = await this.startTest(testType, url, options[testType] || {});
        results[testType] = result;
      } catch (error) {
        errors[testType] = error.message;
      }
    }

    // 计算综合评分
    const overallScore = this.calculateOverallScore(results);

    return {
      url,
      timestamp: new Date().toISOString(),
      results,
      errors,
      overall: overallScore,
      summary: this.generateTestSummary(results, errors)
    };
  }

  /**
   * 计算综合评分
   */
  calculateOverallScore(results) {
    const scores = [];

    Object.values(results).forEach(result => {
      if (result.result && typeof result.result.score === 'number') {
        scores.push(result.result.score);
      } else if (result.result && result.result.summary && typeof result.result.summary.score === 'number') {
        scores.push(result.result.summary.score);
      }
    });

    if (scores.length === 0) {
      return { score: 0, grade: 'F', message: '无法计算评分' };
    }

    const averageScore = scores.reduce((sum, score) => sum + score, 0) / scores.length;

    return {
      score: Math.round(averageScore),
      grade: this.getGrade(averageScore),
      breakdown: scores,
      message: this.getScoreMessage(averageScore)
    };
  }

  /**
   * 获取评级
   */
  getGrade(score) {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
  }

  /**
   * 获取评分说明
   */
  getScoreMessage(score) {
    if (score >= 90) return '优秀 - 网站表现出色';
    if (score >= 80) return '良好 - 网站表现不错，有小幅优化空间';
    if (score >= 70) return '一般 - 网站表现中等，建议优化';
    if (score >= 60) return '较差 - 网站存在明显问题，需要改进';
    return '很差 - 网站存在严重问题，急需优化';
  }

  /**
   * 生成测试摘要
   */
  generateTestSummary(results, errors) {
    const totalTests = Object.keys(results).length + Object.keys(errors).length;
    const successfulTests = Object.keys(results).length;
    const failedTests = Object.keys(errors).length;

    const issues = [];
    const recommendations = [];

    // 收集所有问题和建议
    Object.values(results).forEach(result => {
      if (result.result && result.result.issues) {
        issues.push(...result.result.issues);
      }
      if (result.result && result.result.recommendations) {
        recommendations.push(...result.result.recommendations);
      }
    });

    return {
      totalTests,
      successfulTests,
      failedTests,
      successRate: Math.round((successfulTests / totalTests) * 100),
      totalIssues: issues.length,
      criticalIssues: issues.filter(issue =>
        issue.severity === 'critical' || issue.severity === 'high'
      ).length,
      topRecommendations: recommendations.slice(0, 5)
    };
  }

  /**
   * 获取引擎健康状态
   */
  async getEngineHealthStatus() {
    const status = {};

    for (const [engineType, engine] of Object.entries(this.engines)) {
      try {
        const availability = await this.checkEngineAvailability(engineType);
        status[engineType] = {
          available: availability.available,
          healthy: availability.available && !availability.error,
          lastCheck: new Date().toISOString(),
          version: availability.version,
          error: availability.error
        };
      } catch (error) {
        status[engineType] = {
          available: false,
          healthy: false,
          lastCheck: new Date().toISOString(),
          error: error.message
        };
      }
    }

    return status;
  }

  /**
   * 清理过期的测试数据
   */
  cleanupExpiredTests(maxAge = 24 * 60 * 60 * 1000) { // 24小时
    const now = Date.now();

    for (const [testId, test] of this.activeTests.entries()) {
      if (test.startTime && (now - test.startTime.getTime()) > maxAge) {
        this.activeTests.delete(testId);
      }
    }

    for (const [testId, result] of this.testResults.entries()) {
      if (result.startTime && (now - result.startTime.getTime()) > maxAge) {
        this.testResults.delete(testId);
      }
    }
  }

  /**
   * 测试调度功能
   */
  async scheduleTest(testType, url, options = {}, scheduleOptions = {}) {
    const {
      executeAt,
      recurring = false,
      interval = null,
      maxRetries = 3,
      priority = 'normal'
    } = scheduleOptions;

    const testId = uuidv4();
    const scheduledTest = {
      id: testId,
      testType,
      url,
      options,
      scheduleOptions: {
        executeAt: new Date(executeAt),
        recurring,
        interval,
        maxRetries,
        priority,
        retryCount: 0,
        status: 'scheduled',
        createdAt: new Date()
      }
    };

    // 添加到调度队列
    if (!this.scheduledTests) {
      this.scheduledTests = new Map();
    }
    this.scheduledTests.set(testId, scheduledTest);

    // 如果是立即执行，直接加入执行队列
    if (new Date(executeAt) <= new Date()) {
      this.processScheduledTest(testId);
    }

    return { testId, status: 'scheduled', executeAt };
  }

  /**
   * 处理调度测试
   */
  async processScheduledTest(testId) {
    const scheduledTest = this.scheduledTests?.get(testId);
    if (!scheduledTest) return;

    try {
      const result = await this.startTest(
        scheduledTest.testType,
        scheduledTest.url,
        scheduledTest.options
      );

      // 更新调度状态
      scheduledTest.scheduleOptions.status = 'completed';
      scheduledTest.scheduleOptions.lastExecutedAt = new Date();
      scheduledTest.scheduleOptions.retryCount = 0;

      // 如果是循环任务，安排下次执行
      if (scheduledTest.scheduleOptions.recurring && scheduledTest.scheduleOptions.interval) {
        const nextExecution = new Date(Date.now() + scheduledTest.scheduleOptions.interval);
        scheduledTest.scheduleOptions.executeAt = nextExecution;
        scheduledTest.scheduleOptions.status = 'scheduled';
      } else {
        // 非循环任务完成后移除
        this.scheduledTests.delete(testId);
      }

      return result;
    } catch (error) {
      // 重试逻辑
      scheduledTest.scheduleOptions.retryCount++;
      if (scheduledTest.scheduleOptions.retryCount < scheduledTest.scheduleOptions.maxRetries) {
        const retryDelay = Math.pow(2, scheduledTest.scheduleOptions.retryCount) * 60000; // 指数退避
        scheduledTest.scheduleOptions.executeAt = new Date(Date.now() + retryDelay);
        scheduledTest.scheduleOptions.status = 'retrying';
      } else {
        scheduledTest.scheduleOptions.status = 'failed';
        scheduledTest.scheduleOptions.lastError = error.message;
      }
      throw error;
    }
  }

  /**
   * 获取调度测试列表
   */
  getScheduledTests() {
    if (!this.scheduledTests) return [];
    return Array.from(this.scheduledTests.values()).map(test => ({
      id: test.id,
      testType: test.testType,
      url: test.url,
      ...test.scheduleOptions
    }));
  }

  /**
   * 取消调度测试
   */
  cancelScheduledTest(testId) {
    if (this.scheduledTests?.has(testId)) {
      this.scheduledTests.delete(testId);
      return { success: true, message: '调度测试已取消' };
    }
    return { success: false, message: '调度测试不存在' };
  }

  /**
   * 结果缓存功能
   */
  getCachedResult(testType, url, options = {}) {
    const cacheKey = this.generateCacheKey(testType, url, options);
    if (!this.resultCache) {
      this.resultCache = new Map();
    }

    const cached = this.resultCache.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp) < (options.cacheMaxAge || 300000)) { // 5分钟默认缓存
      return cached.result;
    }
    return null;
  }

  /**
   * 缓存测试结果
   */
  setCachedResult(testType, url, options = {}, result) {
    const cacheKey = this.generateCacheKey(testType, url, options);
    if (!this.resultCache) {
      this.resultCache = new Map();
    }

    this.resultCache.set(cacheKey, {
      result,
      timestamp: Date.now(),
      testType,
      url
    });

    // 限制缓存大小
    if (this.resultCache.size > 1000) {
      const oldestKey = this.resultCache.keys().next().value;
      this.resultCache.delete(oldestKey);
    }
  }

  /**
   * 生成缓存键
   */
  generateCacheKey(testType, url, options) {
    const optionsStr = JSON.stringify(options, Object.keys(options).sort());
    return `${testType}:${url}:${Buffer.from(optionsStr).toString('base64')}`;
  }

  /**
   * 清理缓存
   */
  clearCache(pattern = null) {
    if (!this.resultCache) return { cleared: 0 };

    if (!pattern) {
      const size = this.resultCache.size;
      this.resultCache.clear();
      return { cleared: size };
    }

    let cleared = 0;
    for (const [key, value] of this.resultCache.entries()) {
      if (key.includes(pattern) || value.testType === pattern || value.url.includes(pattern)) {
        this.resultCache.delete(key);
        cleared++;
      }
    }
    return { cleared };
  }

  /**
   * 性能监控功能
   */
  getPerformanceMetrics() {
    const now = Date.now();
    const metrics = {
      activeTests: this.activeTests.size,
      scheduledTests: this.scheduledTests?.size || 0,
      cachedResults: this.resultCache?.size || 0,
      enginesStatus: {},
      systemHealth: {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        cpu: process.cpuUsage()
      }
    };

    // 引擎性能指标
    for (const [engineType] of Object.entries(this.engines)) {
      const engineTests = Array.from(this.activeTests.values())
        .filter(test => test.type === engineType);
      
      metrics.enginesStatus[engineType] = {
        activeTests: engineTests.length,
        avgResponseTime: this.calculateAvgResponseTime(engineType),
        successRate: this.calculateSuccessRate(engineType),
        lastActivity: this.getLastActivity(engineType)
      };
    }

    return metrics;
  }

  /**
   * 计算平均响应时间
   */
  calculateAvgResponseTime(engineType) {
    const recentResults = Array.from(this.testResults.values())
      .filter(result => result.type === engineType && 
        (Date.now() - result.startTime.getTime()) < 3600000) // 最近1小时
      .map(result => result.duration);

    if (recentResults.length === 0) return 0;
    return recentResults.reduce((sum, duration) => sum + duration, 0) / recentResults.length;
  }

  /**
   * 计算成功率
   */
  calculateSuccessRate(engineType) {
    const recentResults = Array.from(this.testResults.values())
      .filter(result => result.type === engineType && 
        (Date.now() - result.startTime.getTime()) < 3600000); // 最近1小时

    if (recentResults.length === 0) return 100;
    const successCount = recentResults.filter(result => result.status === 'completed').length;
    return (successCount / recentResults.length) * 100;
  }

  /**
   * 获取最后活动时间
   */
  getLastActivity(engineType) {
    const engineResults = Array.from(this.testResults.values())
      .filter(result => result.type === engineType)
      .sort((a, b) => b.endTime - a.endTime);

    return engineResults.length > 0 ? engineResults[0].endTime : null;
  }

  /**
   * 批量测试功能
   */
  async runBatchTests(testConfigs, options = {}) {
    const {
      parallel = true,
      maxConcurrency = 5,
      stopOnError = false
    } = options;

    const results = [];
    const errors = [];

    if (parallel) {
      // 并行执行，控制并发数
      const semaphore = new Array(maxConcurrency).fill(null).map(() => Promise.resolve());
      let semaphoreIndex = 0;

      const promises = testConfigs.map(async (config, index) => {
        await semaphore[semaphoreIndex];
        semaphoreIndex = (semaphoreIndex + 1) % maxConcurrency;

        try {
          const result = await this.startTest(config.testType, config.url, config.options || {});
          results[index] = result;
          semaphore[semaphoreIndex % maxConcurrency] = Promise.resolve();
        } catch (error) {
          errors[index] = error;
          if (stopOnError) {
            throw error;
          }
          semaphore[semaphoreIndex % maxConcurrency] = Promise.resolve();
        }
      });

      await Promise.allSettled(promises);
    } else {
      // 顺序执行
      for (let i = 0; i < testConfigs.length; i++) {
        const config = testConfigs[i];
        try {
          const result = await this.startTest(config.testType, config.url, config.options || {});
          results[i] = result;
        } catch (error) {
          errors[i] = error;
          if (stopOnError) {
            break;
          }
        }
      }
    }

    return {
      results,
      errors,
      summary: {
        total: testConfigs.length,
        successful: results.filter(r => r).length,
        failed: errors.filter(e => e).length
      }
    };
  }

  /**
   * 处理调度任务
   */
  processScheduledTasks() {
    if (!this.scheduledTests) return;

    const now = new Date();
    const tasksToExecute = [];

    // 查找需要执行的任务
    for (const [testId, scheduledTest] of this.scheduledTests.entries()) {
      if (scheduledTest.scheduleOptions.status === 'scheduled' && 
          scheduledTest.scheduleOptions.executeAt <= now) {
        tasksToExecute.push(testId);
      }
    }

    // 按优先级排序
    tasksToExecute.sort((a, b) => {
      const testA = this.scheduledTests.get(a);
      const testB = this.scheduledTests.get(b);
      const priorityOrder = { high: 3, normal: 2, low: 1 };
      return priorityOrder[testB.scheduleOptions.priority] - priorityOrder[testA.scheduleOptions.priority];
    });

    // 执行任务
    tasksToExecute.forEach(testId => {
      this.processScheduledTest(testId).catch(error => {
        console.error(`执行调度测试失败: ${testId}`, error);
      });
    });

    return {
      processed: tasksToExecute.length,
      remaining: this.scheduledTests.size - tasksToExecute.length
    };
  }
}

// 创建单例实例
const testEngineService = new TestEngineService();

// 定期清理过期数据和处理调度任务
setInterval(() => {
  testEngineService.cleanupExpiredTests();
  testEngineService.processScheduledTasks();
}, 60 * 60 * 1000); // 每小时清理一次

// 更频繁地检查调度任务
setInterval(() => {
  testEngineService.processScheduledTasks();
}, 60 * 1000); // 每分钟检查一次调度任务

// 创建并导出单例
const testEngineService = new TestEngineService();

module.exports = testEngineService;
module.exports.TestEngineService = TestEngineService;
